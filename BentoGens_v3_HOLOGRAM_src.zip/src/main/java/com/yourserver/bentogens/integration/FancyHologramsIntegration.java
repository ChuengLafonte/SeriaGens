package com.yourserver.bentogens.integration;

import com.yourserver.bentogens.BentoGens;
import com.yourserver.bentogens.models.Generator;
import de.oliver.fancyholograms.api.HologramManager;
import de.oliver.fancyholograms.api.data.TextHologramData;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

import java.util.*;

/**
 * FancyHolograms integration for corrupted generator notifications
 */
public class FancyHologramsIntegration {
    
    private final BentoGens plugin;
    private HologramManager hologramManager;
    private boolean enabled = false;
    private final Map<Location, String> activeHolograms = new HashMap<>();
    
    public FancyHologramsIntegration(BentoGens plugin) {
        this.plugin = plugin;
        tryEnable();
    }
    
    private void tryEnable() {
        Plugin fancyHolograms = plugin.getServer().getPluginManager().getPlugin("FancyHolograms");
        
        if (fancyHolograms == null) {
            plugin.getLogger().info("FancyHolograms not found - hologram notifications disabled");
            return;
        }
        
        try {
            hologramManager = (HologramManager) fancyHolograms;
            enabled = true;
            plugin.getLogger().info("✅ FancyHolograms integration enabled!");
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to enable FancyHolograms: " + e.getMessage());
            enabled = false;
        }
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void showCorruptionHologram(Generator generator) {
        if (!enabled || !plugin.getConfig().getBoolean("hologram.corruption.enabled", true)) {
            return;
        }
        
        Location location = generator.getLocation();
        
        if (activeHolograms.containsKey(location)) {
            return;
        }
        
        try {
            double height = plugin.getConfig().getDouble("hologram.corruption.height", 2.0);
            Location hologramLoc = location.clone().add(0.5, height, 0.5);
            
            String hologramId = "bentogens_corrupted_" + UUID.randomUUID().toString().substring(0, 8);
            
            List<String> lines = plugin.getConfig().getStringList("hologram.corruption.lines");
            if (lines.isEmpty()) {
                int cost = plugin.getConfigManager().getGeneratorsConfig()
                    .getInt(generator.getType() + ".corrupted.cost", 100);
                lines = Arrays.asList(
                    "&c&l⚠ GENERATOR RUSAK!",
                    "&7Repair dengan &e/genset",
                    "&7Cost: &c●" + cost
                );
            }
            
            List<String> coloredLines = new ArrayList<>();
            for (String line : lines) {
                String colored = line.replace("{cost}", 
                    String.valueOf(plugin.getConfigManager().getGeneratorsConfig()
                        .getInt(generator.getType() + ".corrupted.cost", 100)));
                coloredLines.add(plugin.getConfigManager().colorize(colored));
            }
            
            TextHologramData hologramData = TextHologramData.builder()
                .name(hologramId)
                .location(hologramLoc)
                .text(coloredLines)
                .build();
            
            hologramManager.create(hologramData);
            activeHolograms.put(location, hologramId);
            
            plugin.getLogger().info("Created corruption hologram at " + 
                location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ());
            
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to create corruption hologram: " + e.getMessage());
        }
    }
    
    public void removeCorruptionHologram(Generator generator) {
        if (!enabled) {
            return;
        }
        
        Location location = generator.getLocation();
        String hologramId = activeHolograms.get(location);
        
        if (hologramId == null) {
            return;
        }
        
        try {
            var hologram = hologramManager.getHologram(hologramId);
            
            if (hologram != null) {
                hologramManager.delete(hologramId);
                plugin.getLogger().info("Removed corruption hologram at " + 
                    location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ());
            }
            
            activeHolograms.remove(location);
            
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to remove corruption hologram: " + e.getMessage());
        }
    }
    
    public void removeAllHolograms() {
        if (!enabled) {
            return;
        }
        
        plugin.getLogger().info("Removing " + activeHolograms.size() + " corruption holograms...");
        
        for (String hologramId : activeHolograms.values()) {
            try {
                hologramManager.delete(hologramId);
            } catch (Exception e) {
                // Ignore
            }
        }
        
        activeHolograms.clear();
    }
    
    public boolean hasHologram(Location location) {
        return activeHolograms.containsKey(location);
    }
    
    public void reload() {
        removeAllHolograms();
        enabled = false;
        tryEnable();
    }
}
